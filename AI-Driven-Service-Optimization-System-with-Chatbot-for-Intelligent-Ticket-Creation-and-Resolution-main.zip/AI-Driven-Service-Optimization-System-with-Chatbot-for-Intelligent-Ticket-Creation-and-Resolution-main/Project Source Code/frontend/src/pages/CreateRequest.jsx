import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { API } from '@/App';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

const CreateRequest = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    requester_name: '',
    requester_email: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`${API}/requests`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        toast.success('Request created successfully!');
        navigate('/requests');
      } else {
        toast.error('Failed to create request');
      }
    } catch (error) {
      toast.error('An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto fade-in" data-testid="create-request-container">
      <Button
        variant="ghost"
        onClick={() => navigate('/requests')}
        className="mb-4"
        data-testid="back-button"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Requests
      </Button>

      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-slate-800">Create New Service Request</CardTitle>
          <p className="text-slate-600 text-sm mt-2">AI will automatically classify and prioritize your request</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="title" className="text-sm font-medium text-slate-700">
                Request Title *
              </Label>
              <Input
                id="title"
                data-testid="title-input"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                placeholder="Brief description of the issue"
                className="mt-1.5"
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-sm font-medium text-slate-700">
                Description *
              </Label>
              <Textarea
                id="description"
                data-testid="description-input"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                required
                placeholder="Provide detailed information about the service request..."
                className="mt-1.5 min-h-[150px]"
              />
              <p className="text-xs text-slate-500 mt-1">Include keywords like 'urgent', 'critical' for priority classification</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="requester_name" className="text-sm font-medium text-slate-700">
                  Your Name *
                </Label>
                <Input
                  id="requester_name"
                  data-testid="requester-name-input"
                  value={formData.requester_name}
                  onChange={(e) => setFormData({ ...formData, requester_name: e.target.value })}
                  required
                  placeholder="John Doe"
                  className="mt-1.5"
                />
              </div>

              <div>
                <Label htmlFor="requester_email" className="text-sm font-medium text-slate-700">
                  Your Email *
                </Label>
                <Input
                  id="requester_email"
                  data-testid="requester-email-input"
                  type="email"
                  value={formData.requester_email}
                  onChange={(e) => setFormData({ ...formData, requester_email: e.target.value })}
                  required
                  placeholder="john@example.com"
                  className="mt-1.5"
                />
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-blue-800 mb-2">AI Processing Info</h4>
              <p className="text-xs text-blue-700">
                Our AI will analyze your request and automatically:
              </p>
              <ul className="text-xs text-blue-700 ml-4 mt-1 space-y-1">
                <li>• Classify the request category (Technical, Maintenance, Access, Support)</li>
                <li>• Assign priority level based on urgency indicators</li>
                <li>• Predict estimated resolution time</li>
              </ul>
            </div>

            <div className="flex gap-3">
              <Button
                type="submit"
                data-testid="submit-request-button"
                disabled={loading}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
              >
                {loading ? 'Creating...' : 'Create Request'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/requests')}
                className="px-8"
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default CreateRequest;