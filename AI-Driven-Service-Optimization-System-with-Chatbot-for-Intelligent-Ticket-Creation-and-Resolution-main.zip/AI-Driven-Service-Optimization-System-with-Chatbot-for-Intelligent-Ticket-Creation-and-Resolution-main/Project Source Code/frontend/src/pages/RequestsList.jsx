import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { API } from '@/App';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Filter } from 'lucide-react';
import { toast } from 'sonner';

const RequestsList = () => {
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [selectedRequest, setSelectedRequest] = useState(null);

  useEffect(() => {
    fetchRequests();
  }, [statusFilter, priorityFilter]);

  const fetchRequests = async () => {
    try {
      const token = localStorage.getItem('token');
      let url = `${API}/requests`;
      const params = [];
      if (statusFilter !== 'all') params.push(`status=${statusFilter}`);
      if (priorityFilter !== 'all') params.push(`priority=${priorityFilter}`);
      if (params.length > 0) url += `?${params.join('&')}`;

      const response = await fetch(url, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setRequests(data);
      }
    } catch (error) {
      console.error('Error fetching requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateRequestStatus = async (requestId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`${API}/requests/${requestId}`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        toast.success('Status updated successfully');
        fetchRequests();
      }
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  return (
    <div className="space-y-6 fade-in" data-testid="requests-list-container">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Service Requests</h1>
          <p className="text-slate-600">Manage and track all service requests</p>
        </div>
        <Button
          data-testid="create-request-button"
          onClick={() => navigate('/requests/new')}
          className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          New Request
        </Button>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-md">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <Filter className="h-5 w-5 text-slate-600" />
            <div className="flex gap-4 flex-1">
              <div className="flex-1">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger data-testid="status-filter">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger data-testid="priority-filter">
                    <SelectValue placeholder="Filter by priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Requests List */}
      {loading ? (
        <div className="text-center py-12">
          <div className="text-xl text-slate-600">Loading requests...</div>
        </div>
      ) : requests.length === 0 ? (
        <Card className="border-0 shadow-md">
          <CardContent className="py-12 text-center">
            <p className="text-slate-600 text-lg">No requests found</p>
            <p className="text-slate-500 text-sm mt-2">Create a new request to get started</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {requests.map((request) => (
            <Card key={request.id} className="card-hover border-0 shadow-md" data-testid={`request-card-${request.id}`}>
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-slate-800 mb-1">{request.title}</h3>
                    <p className="text-slate-600 text-sm">{request.description}</p>
                  </div>
                  <span className={`status-badge status-${request.status}`} data-testid={`status-${request.id}`}>
                    {request.status.replace('_', ' ')}
                  </span>
                </div>

                <div className="flex gap-2 mb-4">
                  <span className={`status-badge priority-${request.priority}`}>
                    {request.priority}
                  </span>
                  <span className="status-badge" style={{ background: '#f1f5f9', color: '#475569' }}>
                    {request.category}
                  </span>
                  <span className="text-xs text-slate-500 flex items-center">
                    Est: {request.predicted_resolution_hours}h
                  </span>
                </div>

                <div className="flex justify-between items-center text-sm text-slate-500">
                  <div>
                    <span className="font-medium">Requester:</span> {request.requester_name} ({request.requester_email})
                  </div>
                  <div className="flex gap-2">
                    {request.status === 'pending' && (
                      <Button
                        data-testid={`start-progress-${request.id}`}
                        size="sm"
                        onClick={() => updateRequestStatus(request.id, 'in_progress')}
                        variant="outline"
                      >
                        Start Progress
                      </Button>
                    )}
                    {request.status === 'in_progress' && (
                      <Button
                        data-testid={`mark-resolved-${request.id}`}
                        size="sm"
                        onClick={() => updateRequestStatus(request.id, 'resolved')}
                        className="bg-green-500 hover:bg-green-600 text-white"
                      >
                        Mark Resolved
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default RequestsList;