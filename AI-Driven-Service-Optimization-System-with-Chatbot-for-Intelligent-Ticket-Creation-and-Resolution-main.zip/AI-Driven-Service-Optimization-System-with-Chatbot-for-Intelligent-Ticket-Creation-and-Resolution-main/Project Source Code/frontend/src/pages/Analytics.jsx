import { useState, useEffect } from 'react';
import { API } from '@/App';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, BarChart3 } from 'lucide-react';

const Analytics = () => {
  const [stats, setStats] = useState(null);
  const [trends, setTrends] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const token = localStorage.getItem('token');
      
      const [statsRes, trendsRes] = await Promise.all([
        fetch(`${API}/analytics/dashboard`, {
          headers: { 'Authorization': `Bearer ${token}` }
        }),
        fetch(`${API}/analytics/trends`, {
          headers: { 'Authorization': `Bearer ${token}` }
        })
      ]);

      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }

      if (trendsRes.ok) {
        const trendsData = await trendsRes.json();
        setTrends(trendsData);
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-xl text-slate-600">Loading analytics...</div>
      </div>
    );
  }

  const categoryData = stats ? Object.entries(stats.category_distribution).map(([name, value]) => ({ 
    name: name.charAt(0).toUpperCase() + name.slice(1), 
    requests: value 
  })) : [];

  const priorityData = stats ? Object.entries(stats.priority_distribution).map(([name, value]) => ({ 
    name: name.charAt(0).toUpperCase() + name.slice(1), 
    count: value 
  })) : [];

  return (
    <div className="space-y-6 fade-in" data-testid="analytics-container">
      <div>
        <h1 className="text-4xl font-bold text-slate-800 mb-2">Analytics & Insights</h1>
        <p className="text-slate-600">Predictive analytics and performance metrics</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="stat-card border-0">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Avg Resolution Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-800">
              {stats?.avg_resolution_time || 0}h
            </div>
            <p className="text-xs text-slate-500 mt-1">Average time to resolve</p>
          </CardContent>
        </Card>

        <Card className="stat-card border-0">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-slate-600 flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Resolution Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-800">
              {stats?.total_requests > 0 
                ? Math.round((stats.resolved_requests / stats.total_requests) * 100) 
                : 0}%
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {stats?.resolved_requests || 0} of {stats?.total_requests || 0} requests
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card border-0">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-slate-600">Active Workload</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-800">
              {(stats?.pending_requests || 0) + (stats?.in_progress_requests || 0)}
            </div>
            <p className="text-xs text-slate-500 mt-1">Pending + In Progress</p>
          </CardContent>
        </Card>
      </div>

      {/* Trends Chart */}
      {trends?.daily_requests && trends.daily_requests.length > 0 && (
        <Card className="chart-container border-0">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800">Request Trends (Last 30 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={350}>
              <LineChart data={trends.daily_requests}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="date" 
                  stroke="#64748b" 
                  style={{ fontSize: '12px' }}
                  tickFormatter={(value) => {
                    const date = new Date(value);
                    return `${date.getMonth() + 1}/${date.getDate()}`;
                  }}
                />
                <YAxis stroke="#64748b" style={{ fontSize: '12px' }} />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  dot={{ fill: '#3b82f6', r: 4 }}
                  activeDot={{ r: 6 }}
                  name="Requests"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Category & Priority Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="chart-container border-0">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800">Requests by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={categoryData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" stroke="#64748b" style={{ fontSize: '12px' }} />
                <YAxis stroke="#64748b" style={{ fontSize: '12px' }} />
                <Tooltip />
                <Bar dataKey="requests" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="chart-container border-0">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800">Priority Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={priorityData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis type="number" stroke="#64748b" style={{ fontSize: '12px' }} />
                <YAxis dataKey="name" type="category" stroke="#64748b" style={{ fontSize: '12px' }} />
                <Tooltip />
                <Bar dataKey="count" fill="#ec4899" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Insights */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800">AI Insights & Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-semibold text-blue-800 text-sm mb-1">Workload Distribution</h4>
              <p className="text-sm text-blue-700">
                Most requests fall under {categoryData.length > 0 ? categoryData.reduce((a, b) => a.requests > b.requests ? a : b).name : 'N/A'} category. 
                Consider allocating more resources to this area.
              </p>
            </div>
            <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <h4 className="font-semibold text-purple-800 text-sm mb-1">Priority Management</h4>
              <p className="text-sm text-purple-700">
                {stats?.pending_requests > 5 
                  ? `You have ${stats.pending_requests} pending requests. Consider reviewing urgent items first.`
                  : 'Workload is under control. Keep monitoring for new urgent requests.'}
              </p>
            </div>
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <h4 className="font-semibold text-green-800 text-sm mb-1">Performance</h4>
              <p className="text-sm text-green-700">
                Average resolution time is {stats?.avg_resolution_time || 0} hours. 
                {(stats?.avg_resolution_time || 0) < 8 
                  ? ' Excellent response time!' 
                  : ' Consider optimizing workflows to reduce resolution time.'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Analytics;